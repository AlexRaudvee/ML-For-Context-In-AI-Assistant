
from src.codesearch.train.trainer import main

if __name__ == "__main__":
    main()
