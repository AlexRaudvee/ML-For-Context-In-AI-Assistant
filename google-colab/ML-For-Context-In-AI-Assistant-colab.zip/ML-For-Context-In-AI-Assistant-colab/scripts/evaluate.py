
import argparse, json, os
from pathlib import Path
import numpy as np
from codesearch.eval.evaluator import main as eval_main

if __name__ == "__main__":
    eval_main()
